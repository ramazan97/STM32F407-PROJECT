﻿Extract Debug.7z and Drivers.7z in the Root folder itself (where they exist right now)
